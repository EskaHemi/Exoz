import { cn } from '@/lib/utils'

export function MarzbanLogo({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 48 48"
      fill="none"
      aria-hidden="true"
      className={cn('size-12 text-primary', className)}
    >
      <rect x="2" y="2" width="44" height="44" rx="12" fill="currentColor" />
      <path
        d="M13 33V15l11 10 11-10v18"
        stroke="white"
        strokeWidth="4"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}
