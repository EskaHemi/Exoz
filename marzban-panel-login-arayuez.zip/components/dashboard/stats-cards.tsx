import { Activity, ArrowDownUp, MemoryStick } from 'lucide-react'
import { formatBytes, type ProxyUser } from '@/lib/users'

export function StatsCards({ users }: { users: ProxyUser[] }) {
  const activeCount = users.filter((u) => u.status === 'active').length
  const totalUsage = users.reduce((sum, u) => sum + u.usedBytes, 0)
  const memUsed = 1.84 * 1024 ** 3
  const memTotal = 4 * 1024 ** 3

  const stats = [
    {
      title: 'Active Users',
      icon: Activity,
      value: (
        <>
          {activeCount}
          <span className="text-muted-foreground"> / {users.length}</span>
        </>
      ),
    },
    {
      title: 'Data Usage',
      icon: ArrowDownUp,
      value: formatBytes(totalUsage),
    },
    {
      title: 'Memory Usage',
      icon: MemoryStick,
      value: (
        <>
          {formatBytes(memUsed)}
          <span className="text-muted-foreground"> / {formatBytes(memTotal)}</span>
        </>
      ),
    },
  ]

  return (
    <section aria-label="Statistics" className="grid gap-4 sm:grid-cols-3">
      {stats.map(({ title, icon: Icon, value }) => (
        <div
          key={title}
          className="flex items-center justify-between gap-4 rounded-xl border bg-card p-5 shadow-sm"
        >
          <div className="flex items-center gap-3">
            <span className="flex size-10 items-center justify-center rounded-full bg-primary/10 text-primary ring-6 ring-primary/5">
              <Icon className="size-5" />
            </span>
            <span className="text-sm font-medium text-muted-foreground">{title}</span>
          </div>
          <span className="text-lg font-semibold tabular-nums">{value}</span>
        </div>
      ))}
    </section>
  )
}
