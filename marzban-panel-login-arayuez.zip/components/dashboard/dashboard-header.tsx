'use client'

import { useEffect, useRef, useState } from 'react'
import { ExternalLink, LogOut, Menu, Network, Settings, ShieldCheck, Users } from 'lucide-react'
import { logout } from '@/app/actions'
import { ThemeToggle } from '@/components/theme-toggle'
import { MarzbanLogo } from '@/components/marzban-logo'

const menuItems = [
  { label: 'Users', icon: Users },
  { label: 'Host Settings', icon: Network },
  { label: 'Core Settings', icon: Settings },
  { label: 'Nodes', icon: ShieldCheck },
]

export function DashboardHeader({ username }: { username: string }) {
  const [open, setOpen] = useState(false)
  const menuRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!open) return
    function onClick(e: MouseEvent) {
      if (!menuRef.current?.contains(e.target as Node)) setOpen(false)
    }
    function onKey(e: KeyboardEvent) {
      if (e.key === 'Escape') setOpen(false)
    }
    document.addEventListener('mousedown', onClick)
    document.addEventListener('keydown', onKey)
    return () => {
      document.removeEventListener('mousedown', onClick)
      document.removeEventListener('keydown', onKey)
    }
  }, [open])

  return (
    <header className="flex items-center justify-between gap-4">
      <div className="flex items-center gap-3">
        <MarzbanLogo className="size-9" />
        <div>
          <h1 className="text-xl font-semibold tracking-tight">Users</h1>
          <p className="text-xs text-muted-foreground">Logged in as {username}</p>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <div className="relative" ref={menuRef}>
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            aria-haspopup="menu"
            aria-expanded={open}
            aria-label="Open menu"
            className="flex size-9 items-center justify-center rounded-lg border bg-card text-muted-foreground transition hover:bg-muted hover:text-foreground"
          >
            <Menu className="size-4" />
          </button>
          {open && (
            <div
              role="menu"
              className="absolute right-0 z-20 mt-2 w-52 overflow-hidden rounded-lg border bg-popover p-1 text-sm shadow-lg"
            >
              {menuItems.map(({ label, icon: Icon }) => (
                <button
                  key={label}
                  role="menuitem"
                  type="button"
                  onClick={() => setOpen(false)}
                  className="flex w-full items-center gap-2.5 rounded-md px-2.5 py-2 text-left hover:bg-muted"
                >
                  <Icon className="size-4 text-muted-foreground" />
                  {label}
                </button>
              ))}
              <div className="my-1 h-px bg-border" />
              <form action={logout}>
                <button
                  role="menuitem"
                  type="submit"
                  className="flex w-full items-center gap-2.5 rounded-md px-2.5 py-2 text-left text-destructive hover:bg-destructive/10"
                >
                  <LogOut className="size-4" />
                  Log out
                </button>
              </form>
            </div>
          )}
        </div>
        <a
          href="https://github.com/Gozargah/Marzban"
          target="_blank"
          rel="noreferrer"
          aria-label="Marzban on GitHub"
          className="flex size-9 items-center justify-center rounded-lg border bg-card text-muted-foreground transition hover:bg-muted hover:text-foreground"
        >
          <ExternalLink className="size-4" />
        </a>
        <ThemeToggle />
      </div>
    </header>
  )
}
