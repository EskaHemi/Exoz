'use client'

import { useActionState, useEffect } from 'react'
import { Loader2 } from 'lucide-react'
import { createUser, type ActionState } from '@/app/dashboard/actions'
import type { Provider } from '@/lib/users'
import { Modal, inputClass } from './modal'

function CreateUserForm({ providers, onDone }: { providers: Provider[]; onDone: () => void }) {
  const [state, action, pending] = useActionState<ActionState, FormData>(createUser, {})

  useEffect(() => {
    if (state.ok) onDone()
  }, [state, onDone])

  if (providers.length === 0) {
    return (
      <p className="text-sm text-muted-foreground">
        Add a provider first using the <span className="font-medium text-foreground">Providers</span> button.
      </p>
    )
  }

  return (
    <form action={action} className="flex flex-col gap-3">
      <div className="flex flex-col gap-1.5">
        <label htmlFor="new-username" className="text-sm font-medium">
          Username
        </label>
        <input
          id="new-username"
          name="username"
          required
          minLength={3}
          maxLength={32}
          pattern="[a-zA-Z0-9_.\-]+"
          autoComplete="off"
          className={inputClass}
        />
      </div>
      <div className="flex flex-col gap-1.5">
        <label htmlFor="new-provider" className="text-sm font-medium">
          Provider
        </label>
        <select id="new-provider" name="providerId" required className={inputClass}>
          {providers.map((p) => (
            <option key={p.id} value={p.id}>
              {p.name}
            </option>
          ))}
        </select>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div className="flex flex-col gap-1.5">
          <label htmlFor="new-limit" className="text-sm font-medium">
            Data Limit (GB)
          </label>
          <input id="new-limit" name="limitGb" type="number" min={0} step="any" placeholder="0 = unlimited" className={inputClass} />
        </div>
        <div className="flex flex-col gap-1.5">
          <label htmlFor="new-expire" className="text-sm font-medium">
            Expire (days)
          </label>
          <input id="new-expire" name="expireDays" type="number" min={0} step={1} placeholder="0 = never" className={inputClass} />
        </div>
      </div>
      {state.error && (
        <p role="alert" className="text-sm text-red-500">
          {state.error}
        </p>
      )}
      <button
        type="submit"
        disabled={pending}
        className="mt-1 flex h-9 items-center justify-center gap-2 rounded-lg bg-primary px-4 text-sm font-semibold text-primary-foreground hover:bg-primary/90 disabled:opacity-60"
      >
        {pending && <Loader2 className="size-4 animate-spin" />}
        Create User
      </button>
    </form>
  )
}

export function CreateUserDialog({
  open,
  onClose,
  providers,
}: {
  open: boolean
  onClose: () => void
  providers: Provider[]
}) {
  return (
    <Modal open={open} onClose={onClose} title="Create User">
      <CreateUserForm providers={providers} onDone={onClose} />
    </Modal>
  )
}
