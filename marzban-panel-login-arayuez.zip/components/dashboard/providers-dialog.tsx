'use client'

import { useActionState, useEffect, useRef, useTransition } from 'react'
import { Loader2, Trash2 } from 'lucide-react'
import { createProvider, deleteProvider, type ActionState } from '@/app/dashboard/actions'
import type { Provider } from '@/lib/users'
import { Modal, inputClass } from './modal'

function ProviderRow({ provider }: { provider: Provider }) {
  const [pending, startTransition] = useTransition()
  return (
    <li className="flex items-center justify-between gap-3 rounded-lg border px-3 py-2.5">
      <div className="min-w-0">
        <p className="truncate text-sm font-medium">{provider.name}</p>
        <p className="truncate text-xs text-muted-foreground">{provider.subUrl}</p>
        <p className="text-xs text-muted-foreground">{provider.userCount} users</p>
      </div>
      <button
        type="button"
        disabled={pending}
        onClick={() => {
          if (confirm(`Delete provider "${provider.name}"?`)) {
            startTransition(() => deleteProvider(provider.id))
          }
        }}
        aria-label={`Delete provider ${provider.name}`}
        className="flex size-8 shrink-0 items-center justify-center rounded-md text-red-500 hover:bg-red-500/10 disabled:opacity-50"
      >
        {pending ? <Loader2 className="size-4 animate-spin" /> : <Trash2 className="size-4" />}
      </button>
    </li>
  )
}

export function ProvidersDialog({
  open,
  onClose,
  providers,
}: {
  open: boolean
  onClose: () => void
  providers: Provider[]
}) {
  const [state, action, pending] = useActionState<ActionState, FormData>(createProvider, {})
  const formRef = useRef<HTMLFormElement>(null)

  useEffect(() => {
    if (state.ok) formRef.current?.reset()
  }, [state])

  return (
    <Modal open={open} onClose={onClose} title="Providers">
      <div className="flex flex-col gap-5">
        <form ref={formRef} action={action} className="flex flex-col gap-3">
          <div className="flex flex-col gap-1.5">
            <label htmlFor="provider-name" className="text-sm font-medium">
              Name
            </label>
            <input id="provider-name" name="name" required maxLength={64} placeholder="My provider" className={inputClass} />
          </div>
          <div className="flex flex-col gap-1.5">
            <label htmlFor="provider-url" className="text-sm font-medium">
              Subs URL
            </label>
            <input
              id="provider-url"
              name="subUrl"
              type="url"
              required
              placeholder="https://example.com/sub/..."
              className={inputClass}
            />
          </div>
          {state.error && (
            <p role="alert" className="text-sm text-red-500">
              {state.error}
            </p>
          )}
          <button
            type="submit"
            disabled={pending}
            className="flex h-9 items-center justify-center gap-2 rounded-lg bg-primary px-4 text-sm font-semibold text-primary-foreground hover:bg-primary/90 disabled:opacity-60"
          >
            {pending && <Loader2 className="size-4 animate-spin" />}
            Add Provider
          </button>
        </form>

        <div className="flex flex-col gap-2">
          <h3 className="text-sm font-medium text-muted-foreground">Saved providers</h3>
          {providers.length === 0 ? (
            <p className="rounded-lg border border-dashed px-3 py-6 text-center text-sm text-muted-foreground">
              No providers yet
            </p>
          ) : (
            <ul className="flex max-h-60 flex-col gap-2 overflow-y-auto">
              {providers.map((p) => (
                <ProviderRow key={p.id} provider={p} />
              ))}
            </ul>
          )}
        </div>
      </div>
    </Modal>
  )
}
