'use client'

import { useMemo, useState, useTransition } from 'react'
import { useRouter } from 'next/navigation'
import {
  ChevronLeft,
  ChevronRight,
  Copy,
  Check,
  Loader2,
  Pause,
  Play,
  Plus,
  RefreshCw,
  Search,
  Server,
  Trash2,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { formatBytes, type Provider, type ProxyUser, type UserStatus } from '@/lib/users'
import { deleteUser, toggleUser } from '@/app/dashboard/actions'
import { ProvidersDialog } from './providers-dialog'
import { CreateUserDialog } from './create-user-dialog'

const statusStyles: Record<UserStatus, string> = {
  active: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400',
  expired: 'bg-amber-500/10 text-amber-600 dark:text-amber-400',
  limited: 'bg-red-500/10 text-red-600 dark:text-red-400',
  disabled: 'bg-muted text-muted-foreground',
  on_hold: 'bg-violet-500/10 text-violet-600 dark:text-violet-400',
}

const statusLabels: Record<UserStatus, string> = {
  active: 'Active',
  expired: 'Expired',
  limited: 'Limited',
  disabled: 'Disabled',
  on_hold: 'On Hold',
}

const resetLabels = { day: 'daily', week: 'weekly', month: 'monthly' } as const

const PAGE_SIZE = 8

const iconButton =
  'flex size-8 items-center justify-center rounded-md text-muted-foreground hover:bg-muted hover:text-foreground disabled:opacity-50'

function expiryText(days: number | null) {
  if (days === null) return 'Never expires'
  if (days < 0) return `Expired ${Math.abs(days)} days ago`
  return `Expires in ${days} days`
}

function UsageBar({ user }: { user: ProxyUser }) {
  const percent = user.limitBytes ? Math.min((user.usedBytes / user.limitBytes) * 100, 100) : 0
  const tone = percent >= 100 ? 'bg-red-500' : percent >= 80 ? 'bg-amber-500' : 'bg-primary'

  return (
    <div className="flex min-w-40 flex-col gap-1.5">
      <div
        className="h-1.5 w-full overflow-hidden rounded-full bg-muted"
        role="progressbar"
        aria-valuenow={Math.round(percent)}
        aria-valuemin={0}
        aria-valuemax={100}
        aria-label={`${user.username} data usage`}
      >
        <div
          className={cn('h-full rounded-full', user.limitBytes ? tone : 'bg-primary/40')}
          style={{ width: user.limitBytes ? `${percent}%` : '100%' }}
        />
      </div>
      <div className="flex justify-between text-xs text-muted-foreground tabular-nums">
        <span>
          {formatBytes(user.usedBytes)} / {user.limitBytes ? formatBytes(user.limitBytes) : '∞'}
        </span>
        {user.resetStrategy !== 'no_reset' && <span>Resets {resetLabels[user.resetStrategy]}</span>}
      </div>
    </div>
  )
}

function CopyButton({ user }: { user: ProxyUser }) {
  const [copied, setCopied] = useState(false)
  async function copy() {
    await navigator.clipboard?.writeText(user.subUrl).catch(() => {})
    setCopied(true)
    setTimeout(() => setCopied(false), 1500)
  }
  return (
    <button
      type="button"
      onClick={copy}
      title={user.subUrl}
      aria-label={`Copy subscription link for ${user.username}`}
      className={iconButton}
    >
      {copied ? <Check className="size-4 text-emerald-500" /> : <Copy className="size-4" />}
    </button>
  )
}

function UserActions({ user }: { user: ProxyUser }) {
  const [pending, startTransition] = useTransition()
  const [busy, setBusy] = useState<'toggle' | 'delete' | null>(null)
  const disabled = user.status === 'disabled'

  function run(kind: 'toggle' | 'delete') {
    if (kind === 'delete' && !confirm(`Delete user "${user.username}"?`)) return
    setBusy(kind)
    startTransition(async () => {
      const result = kind === 'toggle' ? await toggleUser(user.id) : await deleteUser(user.id)
      if (result.error) alert(result.error)
      setBusy(null)
    })
  }

  return (
    <div className="flex justify-end gap-1">
      <CopyButton user={user} />
      <button
        type="button"
        onClick={() => run('toggle')}
        disabled={pending}
        aria-label={disabled ? `Resume ${user.username}` : `Stop ${user.username}`}
        title={disabled ? 'Resume' : 'Stop'}
        className={cn(iconButton, disabled ? 'text-emerald-500' : 'text-amber-500')}
      >
        {busy === 'toggle' ? (
          <Loader2 className="size-4 animate-spin" />
        ) : disabled ? (
          <Play className="size-4" />
        ) : (
          <Pause className="size-4" />
        )}
      </button>
      <button
        type="button"
        onClick={() => run('delete')}
        disabled={pending}
        aria-label={`Delete ${user.username}`}
        title="Delete"
        className={cn(iconButton, 'text-red-500 hover:bg-red-500/10 hover:text-red-500')}
      >
        {busy === 'delete' ? <Loader2 className="size-4 animate-spin" /> : <Trash2 className="size-4" />}
      </button>
    </div>
  )
}

export function UsersTable({ users, providers }: { users: ProxyUser[]; providers: Provider[] }) {
  const router = useRouter()
  const [refreshing, startRefresh] = useTransition()
  const [query, setQuery] = useState('')
  const [status, setStatus] = useState<UserStatus | 'all'>('all')
  const [page, setPage] = useState(1)
  const [dialog, setDialog] = useState<'providers' | 'create' | null>(null)

  const filtered = useMemo(
    () =>
      users.filter(
        (u) =>
          u.username.toLowerCase().includes(query.trim().toLowerCase()) &&
          (status === 'all' || u.status === status),
      ),
    [users, query, status],
  )

  const pageCount = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE))
  const currentPage = Math.min(page, pageCount)
  const rows = filtered.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE)

  return (
    <section aria-label="Users" className="flex flex-col gap-4">
      <div className="flex justify-end">
        <button
          type="button"
          onClick={() => setDialog('providers')}
          className="flex h-9 items-center gap-2 rounded-lg border bg-card px-4 text-sm font-semibold hover:bg-muted"
        >
          <Server className="size-4" />
          Sağlayıcılar
          <span className="rounded-md bg-muted px-1.5 text-xs text-muted-foreground tabular-nums">
            {providers.length}
          </span>
        </button>
      </div>

      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-1 flex-col gap-3 sm:flex-row sm:items-center">
          <div className="relative w-full sm:max-w-xs">
            <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
            <label htmlFor="user-search" className="sr-only">
              Search users
            </label>
            <input
              id="user-search"
              type="search"
              value={query}
              onChange={(e) => {
                setQuery(e.target.value)
                setPage(1)
              }}
              placeholder="Search"
              className="h-9 w-full rounded-lg border border-input bg-card pr-3 pl-9 text-sm outline-none focus:border-primary focus:ring-3 focus:ring-primary/20"
            />
          </div>
          <label htmlFor="status-filter" className="sr-only">
            Filter by status
          </label>
          <select
            id="status-filter"
            value={status}
            onChange={(e) => {
              setStatus(e.target.value as UserStatus | 'all')
              setPage(1)
            }}
            className="h-9 rounded-lg border border-input bg-card px-3 text-sm outline-none focus:border-primary focus:ring-3 focus:ring-primary/20"
          >
            <option value="all">All statuses</option>
            {Object.entries(statusLabels).map(([value, label]) => (
              <option key={value} value={value}>
                {label}
              </option>
            ))}
          </select>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => startRefresh(() => router.refresh())}
            aria-label="Refresh users"
            className="flex size-9 items-center justify-center rounded-lg border bg-card text-muted-foreground hover:bg-muted hover:text-foreground"
          >
            <RefreshCw className={cn('size-4', refreshing && 'animate-spin')} />
          </button>
          <button
            type="button"
            onClick={() => setDialog('create')}
            className="flex h-9 flex-1 items-center justify-center gap-2 rounded-lg bg-primary px-4 text-sm font-semibold text-primary-foreground hover:bg-primary/90 sm:flex-none"
          >
            <Plus className="size-4" />
            Create User
          </button>
        </div>
      </div>

      <div className="overflow-hidden rounded-xl border bg-card shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-left text-xs font-medium tracking-wide text-muted-foreground uppercase">
              <tr>
                <th scope="col" className="px-5 py-3">Username</th>
                <th scope="col" className="px-5 py-3">Status</th>
                <th scope="col" className="px-5 py-3">Data Usage</th>
                <th scope="col" className="px-5 py-3">
                  <span className="sr-only">Actions</span>
                </th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {rows.map((user) => (
                <tr key={user.id} className="transition hover:bg-muted/40">
                  <td className="px-5 py-3.5">
                    <div className="flex flex-col">
                      <span className="font-medium">{user.username}</span>
                      {user.providerName && (
                        <span className="text-xs text-muted-foreground">{user.providerName}</span>
                      )}
                    </div>
                  </td>
                  <td className="px-5 py-3.5">
                    <div className="flex flex-col items-start gap-1">
                      <span className={cn('rounded-md px-2 py-0.5 text-xs font-medium', statusStyles[user.status])}>
                        {statusLabels[user.status]}
                      </span>
                      <span className="text-xs whitespace-nowrap text-muted-foreground">
                        {expiryText(user.expireInDays)}
                      </span>
                    </div>
                  </td>
                  <td className="px-5 py-3.5">
                    <UsageBar user={user} />
                  </td>
                  <td className="px-5 py-3.5">
                    <UserActions user={user} />
                  </td>
                </tr>
              ))}
              {rows.length === 0 && (
                <tr>
                  <td colSpan={4} className="px-5 py-12 text-center text-muted-foreground">
                    No users found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <nav aria-label="Pagination" className="flex items-center justify-between text-sm">
        <span className="text-muted-foreground">
          {filtered.length} users · Page {currentPage} of {pageCount}
        </span>
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={() => setPage(currentPage - 1)}
            disabled={currentPage === 1}
            className="flex h-8 items-center gap-1 rounded-md border bg-card px-2.5 hover:bg-muted disabled:opacity-50"
          >
            <ChevronLeft className="size-4" />
            Previous
          </button>
          <button
            type="button"
            onClick={() => setPage(currentPage + 1)}
            disabled={currentPage === pageCount}
            className="flex h-8 items-center gap-1 rounded-md border bg-card px-2.5 hover:bg-muted disabled:opacity-50"
          >
            Next
            <ChevronRight className="size-4" />
          </button>
        </div>
      </nav>

      <ProvidersDialog open={dialog === 'providers'} onClose={() => setDialog(null)} providers={providers} />
      <CreateUserDialog open={dialog === 'create'} onClose={() => setDialog(null)} providers={providers} />
    </section>
  )
}
