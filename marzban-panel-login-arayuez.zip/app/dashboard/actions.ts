'use server'

import { randomBytes } from 'node:crypto'
import { eq } from 'drizzle-orm'
import { revalidatePath } from 'next/cache'
import { headers } from 'next/headers'
import { getAdmin } from '@/lib/auth'
import { db } from '@/lib/db'
import { providers, proxyUsers } from '@/lib/db/schema'
import { deleteSubscription, isGcsConfigured, publicSubUrl, uploadSubscription } from '@/lib/gcs'
import { fetchProviderContent } from '@/lib/subscription'

export type ActionState = { error?: string; ok?: boolean }

const GB = 1024 ** 3
const DAY = 24 * 60 * 60 * 1000
const USERNAME_RE = /^[a-zA-Z0-9_.-]{3,32}$/

async function requireAdmin() {
  const admin = await getAdmin()
  if (!admin) throw new Error('Unauthorized')
}

function errorMessage(error: unknown) {
  return error instanceof Error ? error.message : 'Something went wrong'
}

function parseHttpUrl(value: string) {
  try {
    const url = new URL(value)
    return url.protocol === 'http:' || url.protocol === 'https:' ? url : null
  } catch {
    return null
  }
}

async function panelSubUrl(token: string) {
  const h = await headers()
  const host = h.get('x-forwarded-host') ?? h.get('host')
  const proto = h.get('x-forwarded-proto') ?? 'https'
  return `${proto}://${host}/api/sub/${token}`
}

async function getProviderSubUrl(providerId: number | null) {
  if (!providerId) throw new Error('This user has no provider')
  const [provider] = await db.select().from(providers).where(eq(providers.id, providerId))
  if (!provider) throw new Error('Provider not found')
  return provider.subUrl
}

export async function createProvider(_prev: ActionState, formData: FormData): Promise<ActionState> {
  await requireAdmin()
  const name = String(formData.get('name') ?? '').trim()
  const subUrl = String(formData.get('subUrl') ?? '').trim()

  if (!name || name.length > 64) return { error: 'Name is required (max 64 characters)' }
  if (!parseHttpUrl(subUrl)) return { error: 'Enter a valid http(s) Subs URL' }

  try {
    await fetchProviderContent(subUrl)
  } catch (error) {
    return { error: `Could not read Subs URL: ${errorMessage(error)}` }
  }

  await db.insert(providers).values({ name, subUrl })
  revalidatePath('/dashboard')
  return { ok: true }
}

export async function deleteProvider(id: number) {
  await requireAdmin()
  await db.delete(providers).where(eq(providers.id, id))
  revalidatePath('/dashboard')
}

export async function createUser(_prev: ActionState, formData: FormData): Promise<ActionState> {
  await requireAdmin()
  const username = String(formData.get('username') ?? '').trim()
  const providerId = Number(formData.get('providerId'))
  const limitGb = Number(formData.get('limitGb') || 0)
  const expireDays = Number(formData.get('expireDays') || 0)

  if (!USERNAME_RE.test(username)) {
    return { error: 'Username must be 3-32 characters: letters, numbers, _ . -' }
  }
  if (!Number.isInteger(providerId) || providerId <= 0) return { error: 'Select a provider' }
  if (!Number.isFinite(limitGb) || limitGb < 0 || limitGb > 100000) return { error: 'Invalid data limit' }
  if (!Number.isInteger(expireDays) || expireDays < 0 || expireDays > 3650) return { error: 'Invalid expiry days' }

  const [existing] = await db.select({ id: proxyUsers.id }).from(proxyUsers).where(eq(proxyUsers.username, username))
  if (existing) return { error: 'Username already exists' }

  const token = randomBytes(16).toString('hex')
  const useGcs = isGcsConfigured()
  try {
    const content = await fetchProviderContent(await getProviderSubUrl(providerId))
    if (useGcs) await uploadSubscription(token, content)
  } catch (error) {
    return { error: errorMessage(error) }
  }

  await db.insert(proxyUsers).values({
    username,
    providerId,
    limitBytes: limitGb > 0 ? Math.round(limitGb * GB) : null,
    expireAt: expireDays > 0 ? new Date(Date.now() + expireDays * DAY) : null,
    subToken: token,
    subUrl: useGcs ? publicSubUrl(token) : await panelSubUrl(token),
  })
  revalidatePath('/dashboard')
  return { ok: true }
}

export async function toggleUser(id: number): Promise<ActionState> {
  await requireAdmin()
  const [user] = await db.select().from(proxyUsers).where(eq(proxyUsers.id, id))
  if (!user) return { error: 'User not found' }

  const disabling = user.status !== 'disabled'
  const onGcs = user.subUrl.startsWith('https://storage.googleapis.com/')
  if (onGcs) try {
    if (disabling) {
      await uploadSubscription(user.subToken, '')
    } else {
      const content = await fetchProviderContent(await getProviderSubUrl(user.providerId))
      await uploadSubscription(user.subToken, content)
    }
  } catch (error) {
    return { error: errorMessage(error) }
  }

  await db
    .update(proxyUsers)
    .set({ status: disabling ? 'disabled' : 'active' })
    .where(eq(proxyUsers.id, id))
  revalidatePath('/dashboard')
  return { ok: true }
}

export async function deleteUser(id: number): Promise<ActionState> {
  await requireAdmin()
  const [user] = await db.select().from(proxyUsers).where(eq(proxyUsers.id, id))
  if (!user) return { error: 'User not found' }

  if (user.subUrl.startsWith('https://storage.googleapis.com/')) {
    try {
      await deleteSubscription(user.subToken)
    } catch (error) {
      return { error: errorMessage(error) }
    }
  }
  await db.delete(proxyUsers).where(eq(proxyUsers.id, id))
  revalidatePath('/dashboard')
  return { ok: true }
}
