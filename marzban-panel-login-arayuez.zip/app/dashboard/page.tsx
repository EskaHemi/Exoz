import type { Metadata } from 'next'
import { redirect } from 'next/navigation'
import { getAdmin } from '@/lib/auth'
import { getProviders, getUsers } from '@/lib/data'
import { DashboardHeader } from '@/components/dashboard/dashboard-header'
import { StatsCards } from '@/components/dashboard/stats-cards'
import { UsersTable } from '@/components/dashboard/users-table'

export const metadata: Metadata = {
  title: 'Dashboard · Marzban',
}

export default async function DashboardPage() {
  const admin = await getAdmin()
  if (!admin) redirect('/')

  const [users, providers] = await Promise.all([getUsers(), getProviders()])

  return (
    <div className="min-h-svh bg-muted/40">
      <main className="mx-auto flex w-full max-w-6xl flex-col gap-6 px-4 py-6 sm:px-6 sm:py-8">
        <DashboardHeader username={admin.username} />
        <StatsCards users={users} />
        <UsersTable users={users} providers={providers} />
      </main>
      <footer className="pb-6 text-center text-xs text-muted-foreground">
        Made with care by Gozargah · Marzban
      </footer>
    </div>
  )
}
