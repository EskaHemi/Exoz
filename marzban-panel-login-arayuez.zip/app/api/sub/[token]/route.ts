import { eq } from 'drizzle-orm'
import { db } from '@/lib/db'
import { providers, proxyUsers } from '@/lib/db/schema'
import { fetchProviderContent } from '@/lib/subscription'

const TOKEN_RE = /^[a-f0-9]{32}$/

function textResponse(body: string, status = 200) {
  return new Response(body, {
    status,
    headers: { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' },
  })
}

export async function GET(_req: Request, { params }: { params: Promise<{ token: string }> }) {
  const { token } = await params
  if (!TOKEN_RE.test(token)) return textResponse('Not found', 404)

  const [user] = await db.select().from(proxyUsers).where(eq(proxyUsers.subToken, token))
  if (!user) return textResponse('Not found', 404)

  const expired = user.expireAt !== null && user.expireAt.getTime() < Date.now()
  const limited = user.limitBytes !== null && user.usedBytes >= user.limitBytes
  if (user.status !== 'active' || expired || limited || !user.providerId) return textResponse('')

  const [provider] = await db.select().from(providers).where(eq(providers.id, user.providerId))
  if (!provider) return textResponse('')

  try {
    return textResponse(await fetchProviderContent(provider.subUrl))
  } catch {
    return textResponse('Upstream unavailable', 502)
  }
}
