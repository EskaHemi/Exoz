import { redirect } from 'next/navigation'
import { getAdmin } from '@/lib/auth'
import { LoginForm } from '@/components/login-form'
import { MarzbanLogo } from '@/components/marzban-logo'
import { ThemeToggle } from '@/components/theme-toggle'

export default async function LoginPage() {
  if (await getAdmin()) redirect('/dashboard')

  return (
    <main className="relative flex min-h-svh flex-col items-center justify-center bg-muted/40 px-4 py-10">
      <div className="absolute top-4 right-4">
        <ThemeToggle />
      </div>

      <div className="w-full max-w-sm">
        <div className="mb-8 flex flex-col items-center text-center">
          <MarzbanLogo className="size-14" />
          <h1 className="mt-5 text-2xl font-semibold tracking-tight text-balance">
            Login to your account
          </h1>
          <p className="mt-1.5 text-sm text-muted-foreground">
            Welcome back, please enter your details
          </p>
        </div>

        <div className="rounded-xl border bg-card p-6 shadow-sm">
          <LoginForm />
        </div>
      </div>

      <p className="mt-10 text-xs text-muted-foreground">Marzban Panel · v0.8.4</p>
    </main>
  )
}
