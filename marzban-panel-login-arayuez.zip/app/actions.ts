'use server'

import { redirect } from 'next/navigation'
import { createSession, destroySession, verifyCredentials } from '@/lib/auth'

export type LoginState = { error: string | null }

export async function login(_prev: LoginState, formData: FormData): Promise<LoginState> {
  const username = String(formData.get('username') ?? '').trim()
  const password = String(formData.get('password') ?? '')

  if (!username || !password) {
    return { error: 'Username and password are required.' }
  }
  if (username.length > 64 || password.length > 128) {
    return { error: 'Incorrect username or password.' }
  }
  if (!verifyCredentials(username, password)) {
    return { error: 'Incorrect username or password.' }
  }

  await createSession()
  redirect('/dashboard')
}

export async function logout() {
  await destroySession()
  redirect('/')
}
