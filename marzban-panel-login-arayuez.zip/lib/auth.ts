import 'server-only'
import { createHash, timingSafeEqual } from 'node:crypto'
import { cookies } from 'next/headers'

const ADMIN_USERNAME = 'EzizHemi'
const ADMIN_PASSWORD = '87654321'

export const SESSION_COOKIE = 'marzban_session'

function hash(value: string) {
  return createHash('sha256').update(value).digest()
}

function safeEqual(a: string, b: string) {
  return timingSafeEqual(hash(a), hash(b))
}

function sessionToken() {
  return hash(`marzban:${ADMIN_USERNAME}:${ADMIN_PASSWORD}`).toString('hex')
}

export function verifyCredentials(username: string, password: string) {
  const userOk = safeEqual(username, ADMIN_USERNAME)
  const passOk = safeEqual(password, ADMIN_PASSWORD)
  return userOk && passOk
}

export async function createSession() {
  const store = await cookies()
  store.set(SESSION_COOKIE, sessionToken(), {
    httpOnly: true,
    secure: true,
    sameSite: 'none',
    path: '/',
    maxAge: 60 * 60 * 24,
  })
}

export async function destroySession() {
  const store = await cookies()
  store.delete(SESSION_COOKIE)
}

export async function getAdmin() {
  const store = await cookies()
  const token = store.get(SESSION_COOKIE)?.value
  if (!token || !safeEqual(token, sessionToken())) return null
  return { username: ADMIN_USERNAME }
}
