import 'server-only'
import { asc, count, desc, eq } from 'drizzle-orm'
import { db } from '@/lib/db'
import { providers, proxyUsers } from '@/lib/db/schema'
import type { Provider, ProxyUser, UserStatus } from '@/lib/users'

const DAY = 24 * 60 * 60 * 1000

export async function getUsers(): Promise<ProxyUser[]> {
  const rows = await db
    .select({ user: proxyUsers, providerName: providers.name })
    .from(proxyUsers)
    .leftJoin(providers, eq(proxyUsers.providerId, providers.id))
    .orderBy(desc(proxyUsers.createdAt))

  const now = Date.now()
  return rows.map(({ user, providerName }) => {
    const expireInDays = user.expireAt ? Math.ceil((user.expireAt.getTime() - now) / DAY) : null
    let status = user.status as UserStatus
    if (status === 'active' && expireInDays !== null && expireInDays < 0) status = 'expired'
    if (status === 'active' && user.limitBytes && user.usedBytes >= user.limitBytes) status = 'limited'
    return {
      id: user.id,
      username: user.username,
      status,
      usedBytes: user.usedBytes,
      limitBytes: user.limitBytes,
      expireInDays,
      resetStrategy: user.resetStrategy as ProxyUser['resetStrategy'],
      providerName,
      subUrl: user.subUrl,
    }
  })
}

export async function getProviders(): Promise<Provider[]> {
  const rows = await db
    .select({
      id: providers.id,
      name: providers.name,
      subUrl: providers.subUrl,
      userCount: count(proxyUsers.id),
    })
    .from(providers)
    .leftJoin(proxyUsers, eq(proxyUsers.providerId, providers.id))
    .groupBy(providers.id)
    .orderBy(asc(providers.createdAt))
  return rows
}
