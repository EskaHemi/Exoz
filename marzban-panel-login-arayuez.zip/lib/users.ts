export type UserStatus = 'active' | 'expired' | 'limited' | 'disabled' | 'on_hold'

export type ProxyUser = {
  id: number
  username: string
  status: UserStatus
  usedBytes: number
  limitBytes: number | null
  expireInDays: number | null
  resetStrategy: 'no_reset' | 'day' | 'week' | 'month'
  providerName: string | null
  subUrl: string
}

export type Provider = {
  id: number
  name: string
  subUrl: string
  userCount: number
}

export function formatBytes(bytes: number) {
  if (bytes === 0) return '0 B'
  const units = ['B', 'KB', 'MB', 'GB', 'TB']
  const i = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1)
  const value = bytes / 1024 ** i
  return `${value.toFixed(value >= 100 ? 0 : 1)} ${units[i]}`
}
