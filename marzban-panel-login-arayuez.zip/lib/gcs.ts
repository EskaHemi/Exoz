import 'server-only'
import { Storage } from '@google-cloud/storage'

export function isGcsConfigured() {
  return Boolean(process.env.GCS_BUCKET_NAME && process.env.GCS_SERVICE_ACCOUNT_JSON)
}

function getBucket() {
  const bucketName = process.env.GCS_BUCKET_NAME
  const credentialsJson = process.env.GCS_SERVICE_ACCOUNT_JSON
  if (!bucketName || !credentialsJson) {
    throw new Error('Google Cloud Storage is not configured (GCS_BUCKET_NAME / GCS_SERVICE_ACCOUNT_JSON).')
  }
  const credentials = JSON.parse(credentialsJson)
  const storage = new Storage({ projectId: credentials.project_id, credentials })
  return storage.bucket(bucketName)
}

function objectPath(token: string) {
  return `subs/${token}`
}

export function publicSubUrl(token: string) {
  return `https://storage.googleapis.com/${process.env.GCS_BUCKET_NAME}/${objectPath(token)}`
}

export async function uploadSubscription(token: string, content: string) {
  await getBucket()
    .file(objectPath(token))
    .save(content, {
      resumable: false,
      contentType: 'text/plain; charset=utf-8',
      metadata: { cacheControl: 'no-cache, max-age=0' },
    })
}

export async function deleteSubscription(token: string) {
  await getBucket().file(objectPath(token)).delete({ ignoreNotFound: true })
}
