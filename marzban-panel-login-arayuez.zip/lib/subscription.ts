import 'server-only'

export async function fetchProviderContent(subUrl: string) {
  const res = await fetch(subUrl, {
    cache: 'no-store',
    headers: { 'User-Agent': 'v2rayNG/1.8.5' },
    signal: AbortSignal.timeout(15000),
  })
  if (!res.ok) throw new Error(`Provider Subs URL returned HTTP ${res.status}`)
  const text = await res.text()
  if (!text.trim()) throw new Error('Provider Subs URL returned empty content')
  return text
}
