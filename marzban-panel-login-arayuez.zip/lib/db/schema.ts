import { bigint, integer, pgTable, serial, text, timestamp } from 'drizzle-orm/pg-core'

export const providers = pgTable('providers', {
  id: serial('id').primaryKey(),
  name: text('name').notNull(),
  subUrl: text('sub_url').notNull(),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
})

export const proxyUsers = pgTable('proxy_users', {
  id: serial('id').primaryKey(),
  username: text('username').notNull().unique(),
  status: text('status').notNull().default('active'),
  usedBytes: bigint('used_bytes', { mode: 'number' }).notNull().default(0),
  limitBytes: bigint('limit_bytes', { mode: 'number' }),
  expireAt: timestamp('expire_at', { withTimezone: true }),
  resetStrategy: text('reset_strategy').notNull().default('no_reset'),
  providerId: integer('provider_id'),
  subToken: text('sub_token').notNull().unique(),
  subUrl: text('sub_url').notNull(),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
})
